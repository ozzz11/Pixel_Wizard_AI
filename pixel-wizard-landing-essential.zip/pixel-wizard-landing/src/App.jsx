import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { 
  Download, 
  Zap, 
  Layers, 
  Palette, 
  Monitor, 
  Users, 
  Star, 
  Check, 
  Globe, 
  MessageCircle,
  ChevronDown,
  Play,
  Sparkles,
  Infinity,
  Wand2
} from 'lucide-react';
import './App.css';

// Import images
import heroImage from './assets/hero_futuristic_soldiers.jpg';
import aiVisionImage from './assets/ai_vision_eye.jpg';
import professionalImage from './assets/professional_figure.jpg';
import egyptianWomanImage from './assets/egyptian_woman_phone.jpg';
import appScreenshotTurkish from './assets/app_screenshot_turkish.jpg';
import egyptianGoddessesImage from './assets/egyptian_goddesses.jpg';
import cyberpunkSamuraiImage from './assets/cyberpunk_samurai.jpg';
import cuteCatImage from './assets/cute_cat.jpg';
import appScreenshotRussian from './assets/app_screenshot_russian.jpg';

const translations = {
  tr: {
    nav: {
      features: 'Özellikler',
      gallery: 'Galeri',
      pricing: 'Fiyatlandırma',
      faq: 'SSS',
      download: 'İndir'
    },
    hero: {
      title: 'Pixel Wizard AI',
      subtitle: 'Sınırsız AI Görsel Üretimi',
      description: 'Windows masaüstü uygulaması ile hayal ettiğiniz her görseli saniyeler içinde oluşturun. Kredi limiti yok, abonelik yok - sadece sınırsız yaratıcılık!',
      cta: 'Hemen İndir - $120',
      monthly: 'Aylık $18'
    },
    features: {
      title: 'Neden Pixel Wizard AI?',
      unlimited: {
        title: 'Sınırsız Üretim',
        description: 'Diğer AI servislerinin aksine, kredi sistemi yok! Bir kez satın aldıktan sonra istediğiniz kadar görsel üretin.'
      },
      batch: {
        title: 'Toplu İşleme',
        description: 'Verimliliğinizi 10 kat artırın! Yüzlerce prompt\'u bir metin dosyasına yazın ve otomatik olarak tüm görsellerin oluşturulmasını izleyin.'
      },
      styles: {
        title: 'Profesyonel Stiller',
        description: '20\'den fazla hazır stil ile prompt mühendisi olmaya gerek yok. Tek tıkla profesyonel sonuçlar alın.'
      },
      dimensions: {
        title: 'Platform Boyutları',
        description: 'YouTube kapakları için 16:9, Reels/Shorts/TikTok için 9:16, Instagram postları için 1:1 - doğru formatı tek tıkla seçin.'
      }
    },
    useCases: {
      title: 'Kimler İçin İdeal?',
      youtube: {
        title: 'YouTube İçerik Üreticileri',
        description: 'Benzersiz kapak görselleri ve video illüstrasyonları oluşturun.'
      },
      smm: {
        title: 'Sosyal Medya Yöneticileri',
        description: 'Sürekli orijinal ve çekici görseller için akışınızı hiç kesmeyin.'
      },
      bloggers: {
        title: 'Blog Yazarları',
        description: 'Makalelerinizi kaliteli ve konuyla ilgili görsellerle zenginleştirin.'
      },
      marketers: {
        title: 'Pazarlama Uzmanları',
        description: 'Farklı kreatifler ve görsel konseptler için hızlı test imkanı.'
      }
    },
    pricing: {
      title: 'Basit ve Şeffaf Fiyatlandırma',
      oneTime: 'Tek Seferlik Ödeme: $120',
      monthly: 'Aylık: $18',
      features: [
        'Sınırsız görsel üretimi',
        'Tüm profesyonel stiller',
        'Toplu işleme özelliği',
        'Çoklu dil desteği',
        'Ücretsiz güncellemeler',
        '7/24 teknik destek'
      ]
    },
    faq: {
      title: 'Sıkça Sorulan Sorular',
      q1: 'Windows SmartScreen uyarısı gösteriyor, güvenli mi?',
      a1: 'Evet, tamamen güvenli. Bu yeni bir uygulama olduğu için Windows SmartScreen "tanınmayan uygulama" uyarısı gösterebilir.',
      q2: 'İnternet bağlantısı gerekli mi?',
      a2: 'Evet, görsel üretimi için internet bağlantısı gereklidir. Ancak uygulama masaüstünde çalışır.',
      q3: 'Hangi Windows sürümleri destekleniyor?',
      a3: 'Windows 10 ve Windows 11 tam olarak desteklenmektedir.'
    },
    footer: {
      telegram: 'Telegram Kanalımız',
      rights: 'Tüm hakları saklıdır.'
    }
  },
  en: {
    nav: {
      features: 'Features',
      gallery: 'Gallery',
      pricing: 'Pricing',
      faq: 'FAQ',
      download: 'Download'
    },
    hero: {
      title: 'Pixel Wizard AI',
      subtitle: 'Unlimited AI Image Generation',
      description: 'Create any image you can imagine in seconds with our Windows desktop application. No credit limits, no subscriptions - just unlimited creativity!',
      cta: 'Download Now - $120',
      monthly: 'Monthly $18'
    },
    features: {
      title: 'Why Choose Pixel Wizard AI?',
      unlimited: {
        title: 'Unlimited Generation',
        description: 'Unlike other AI services, there\'s no credit system! Once you purchase, generate as many images as you want.'
      },
      batch: {
        title: 'Batch Processing',
        description: 'Increase your productivity by 10x! Write hundreds of prompts in a text file and watch all images generate automatically.'
      },
      styles: {
        title: 'Professional Styles',
        description: 'No need to be a prompt engineer with 20+ ready-made styles. Get professional results with one click.'
      },
      dimensions: {
        title: 'Platform Dimensions',
        description: '16:9 for YouTube thumbnails, 9:16 for Reels/Shorts/TikTok, 1:1 for Instagram posts - choose the right format with one click.'
      }
    },
    useCases: {
      title: 'Perfect For',
      youtube: {
        title: 'YouTube Content Creators',
        description: 'Create unique thumbnails and video illustrations.'
      },
      smm: {
        title: 'Social Media Managers',
        description: 'Never run out of original and engaging visuals.'
      },
      bloggers: {
        title: 'Blog Writers',
        description: 'Enrich your articles with quality and relevant images.'
      },
      marketers: {
        title: 'Marketing Specialists',
        description: 'Quick testing opportunities for different creatives and visual concepts.'
      }
    },
    pricing: {
      title: 'Simple and Transparent Pricing',
      oneTime: 'One-Time Payment: $120',
      monthly: 'Monthly: $18',
      features: [
        'Unlimited image generation',
        'All professional styles',
        'Batch processing feature',
        'Multi-language support',
        'Free updates',
        '24/7 technical support'
      ]
    },
    faq: {
      title: 'Frequently Asked Questions',
      q1: 'Windows SmartScreen shows a warning, is it safe?',
      a1: 'Yes, completely safe. Since this is a new application, Windows SmartScreen may show an "unrecognized app" warning.',
      q2: 'Is internet connection required?',
      a2: 'Yes, internet connection is required for image generation. However, the application runs on desktop.',
      q3: 'Which Windows versions are supported?',
      a3: 'Windows 10 and Windows 11 are fully supported.'
    },
    footer: {
      telegram: 'Our Telegram Channel',
      rights: 'All rights reserved.'
    }
  },
  ru: {
    nav: {
      features: 'Функции',
      gallery: 'Галерея',
      pricing: 'Цены',
      faq: 'FAQ',
      download: 'Скачать'
    },
    hero: {
      title: 'Pixel Wizard AI',
      subtitle: 'Безлимитная генерация изображений',
      description: 'Создавайте любые изображения, которые можете представить, за секунды с нашим десктопным приложением для Windows. Никаких лимитов кредитов, никаких подписок - только безграничное творчество!',
      cta: 'Скачать сейчас - $120',
      monthly: 'Ежемесячно $18'
    },
    features: {
      title: 'Почему стоит выбрать Pixel Wizard AI?',
      unlimited: {
        title: 'Безлимитная генерация',
        description: 'В отличие от других AI-сервисов, никакой системы кредитов! После покупки генерируйте столько изображений, сколько хотите.'
      },
      batch: {
        title: 'Пакетная обработка',
        description: 'Увеличьте продуктивность в 10 раз! Напишите сотни промптов в текстовый файл и наблюдайте автоматическую генерацию.'
      },
      styles: {
        title: 'Профессиональные стили',
        description: 'Не нужно быть инженером промптов с 20+ готовыми стилями. Получайте профессиональные результаты одним кликом.'
      },
      dimensions: {
        title: 'Размеры для платформ',
        description: '16:9 для обложек YouTube, 9:16 для Reels/Shorts/TikTok, 1:1 для постов Instagram - выберите правильный формат одним кликом.'
      }
    },
    useCases: {
      title: 'Идеально подходит для',
      youtube: {
        title: 'YouTube-блогеров',
        description: 'Создавайте уникальные обложки и иллюстрации к видео.'
      },
      smm: {
        title: 'SMM-менеджеров',
        description: 'Никогда не заканчивайтесь оригинальными и привлекательными визуалами.'
      },
      bloggers: {
        title: 'Авторов блогов',
        description: 'Обогащайте статьи качественными и релевантными изображениями.'
      },
      marketers: {
        title: 'Маркетологов',
        description: 'Быстрые возможности тестирования различных креативов и визуальных концепций.'
      }
    },
    pricing: {
      title: 'Простое и прозрачное ценообразование',
      oneTime: 'Единоразовый платеж: $120',
      monthly: 'Ежемесячно: $18',
      features: [
        'Безлимитная генерация изображений',
        'Все профессиональные стили',
        'Функция пакетной обработки',
        'Поддержка нескольких языков',
        'Бесплатные обновления',
        'Техническая поддержка 24/7'
      ]
    },
    faq: {
      title: 'Часто задаваемые вопросы',
      q1: 'Windows SmartScreen показывает предупреждение, безопасно ли это?',
      a1: 'Да, полностью безопасно. Поскольку это новое приложение, Windows SmartScreen может показать предупреждение о "нераспознанном приложении".',
      q2: 'Требуется ли подключение к интернету?',
      a2: 'Да, для генерации изображений требуется подключение к интернету. Однако приложение работает на рабочем столе.',
      q3: 'Какие версии Windows поддерживаются?',
      a3: 'Windows 10 и Windows 11 полностью поддерживаются.'
    },
    footer: {
      telegram: 'Наш Telegram канал',
      rights: 'Все права защищены.'
    }
  }
};

function App() {
  const [currentLang, setCurrentLang] = useState('tr');
  const [isScrolled, setIsScrolled] = useState(false);
  const t = translations[currentLang];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Navigation */}
      <motion.nav 
        className={`fixed top-0 w-full z-50 transition-all duration-300 ${
          isScrolled ? 'bg-black/80 backdrop-blur-md' : 'bg-transparent'
        }`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Wand2 className="h-8 w-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">Pixel Wizard AI</span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <button onClick={() => scrollToSection('features')} className="text-white hover:text-purple-400 transition-colors">
              {t.nav.features}
            </button>
            <button onClick={() => scrollToSection('gallery')} className="text-white hover:text-purple-400 transition-colors">
              {t.nav.gallery}
            </button>
            <button onClick={() => scrollToSection('pricing')} className="text-white hover:text-purple-400 transition-colors">
              {t.nav.pricing}
            </button>
            <button onClick={() => scrollToSection('faq')} className="text-white hover:text-purple-400 transition-colors">
              {t.nav.faq}
            </button>
          </div>

          <div className="flex items-center space-x-4">
            <select 
              value={currentLang} 
              onChange={(e) => setCurrentLang(e.target.value)}
              className="bg-white/10 text-white border border-white/20 rounded-lg px-3 py-1 text-sm"
            >
              <option value="tr">🇹🇷 Türkçe</option>
              <option value="en">🇺🇸 English</option>
              <option value="ru">🇷🇺 Русский</option>
            </select>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Download className="h-4 w-4 mr-2" />
              {t.nav.download}
            </Button>
          </div>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroImage} 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-purple-900/80 to-slate-900/80"></div>
        </div>
        
        <div className="relative z-10 container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Badge className="mb-6 bg-purple-600/20 text-purple-300 border-purple-500/30">
              <Sparkles className="h-4 w-4 mr-2" />
              Sınırsız AI Yaratıcılığı
            </Badge>
            
            <h1 className="text-6xl md:text-8xl font-bold text-white mb-6 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              {t.hero.title}
            </h1>
            
            <h2 className="text-2xl md:text-4xl text-purple-300 mb-8 font-light">
              {t.hero.subtitle}
            </h2>
            
            <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
              {t.hero.description}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-4 text-lg">
                <Download className="h-5 w-5 mr-2" />
                {t.hero.cta}
              </Button>
              <Button size="lg" variant="outline" className="border-purple-400 text-purple-300 hover:bg-purple-600/20 px-8 py-4 text-lg">
                {t.hero.monthly}
              </Button>
            </div>
          </motion.div>
        </div>

        <motion.div 
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <ChevronDown className="h-8 w-8 text-purple-400" />
        </motion.div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
              {t.features.title}
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Infinity className="h-12 w-12 text-purple-400" />,
                title: t.features.unlimited.title,
                description: t.features.unlimited.description
              },
              {
                icon: <Layers className="h-12 w-12 text-blue-400" />,
                title: t.features.batch.title,
                description: t.features.batch.description
              },
              {
                icon: <Palette className="h-12 w-12 text-pink-400" />,
                title: t.features.styles.title,
                description: t.features.styles.description
              },
              {
                icon: <Monitor className="h-12 w-12 text-green-400" />,
                title: t.features.dimensions.title,
                description: t.features.dimensions.description
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
              >
                <Card className="bg-white/5 border-white/10 backdrop-blur-sm h-full hover:bg-white/10 transition-all duration-300">
                  <CardHeader className="text-center">
                    <div className="mx-auto mb-4">
                      {feature.icon}
                    </div>
                    <CardTitle className="text-white text-xl">
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-gray-300 text-center">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* App Screenshots */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mt-20 text-center"
          >
            <h3 className="text-3xl font-bold text-white mb-8">Uygulama Arayüzü</h3>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <div className="relative group">
                <img 
                  src={appScreenshotTurkish} 
                  alt="Turkish Interface" 
                  className="w-full rounded-lg shadow-2xl group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-lg"></div>
                <Badge className="absolute bottom-4 left-4 bg-blue-600">Türkçe Arayüz</Badge>
              </div>
              <div className="relative group">
                <img 
                  src={appScreenshotRussian} 
                  alt="Russian Interface" 
                  className="w-full rounded-lg shadow-2xl group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-lg"></div>
                <Badge className="absolute bottom-4 left-4 bg-red-600">Русский интерфейс</Badge>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-20 bg-gradient-to-r from-purple-900/20 to-pink-900/20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Stil Çeşitliliği
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Pixel Wizard AI ile oluşturabileceğiniz görsel stillerin sadece birkaç örneği
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { image: cyberpunkSamuraiImage, title: "Cyberpunk Anime", style: "Modern Anime + Neon" },
              { image: egyptianGoddessesImage, title: "Antik Sanat", style: "Klasik Mitoloji" },
              { image: egyptianWomanImage, title: "Tarih + Modern", style: "Zaman Karışımı" },
              { image: cuteCatImage, title: "Sevimli Karakter", style: "Cartoon Style" },
              { image: aiVisionImage, title: "Sürreal Sanat", style: "Dramatik Kompozisyon" },
              { image: professionalImage, title: "Kurumsal Stil", style: "Profesyonel Görünüm" }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="relative group cursor-pointer"
              >
                <div className="relative overflow-hidden rounded-lg">
                  <img 
                    src={item.image} 
                    alt={item.title}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute bottom-4 left-4 right-4 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="text-white font-bold text-lg">{item.title}</h3>
                    <p className="text-purple-300 text-sm">{item.style}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
              {t.useCases.title}
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Play className="h-12 w-12 text-red-400" />,
                title: t.useCases.youtube.title,
                description: t.useCases.youtube.description
              },
              {
                icon: <Users className="h-12 w-12 text-blue-400" />,
                title: t.useCases.smm.title,
                description: t.useCases.smm.description
              },
              {
                icon: <MessageCircle className="h-12 w-12 text-green-400" />,
                title: t.useCases.bloggers.title,
                description: t.useCases.bloggers.description
              },
              {
                icon: <Zap className="h-12 w-12 text-yellow-400" />,
                title: t.useCases.marketers.title,
                description: t.useCases.marketers.description
              }
            ].map((useCase, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
              >
                <Card className="bg-white/5 border-white/10 backdrop-blur-sm h-full hover:bg-white/10 transition-all duration-300">
                  <CardHeader className="text-center">
                    <div className="mx-auto mb-4">
                      {useCase.icon}
                    </div>
                    <CardTitle className="text-white text-xl">
                      {useCase.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-gray-300 text-center">
                      {useCase.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-gradient-to-r from-purple-900/20 to-pink-900/20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
              {t.pricing.title}
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              whileHover={{ scale: 1.05 }}
            >
              <Card className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 border-purple-500/30 backdrop-blur-sm h-full relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-gradient-to-l from-purple-500 to-pink-500 text-white px-4 py-2 text-sm font-bold">
                  EN POPÜLER
                </div>
                <CardHeader className="text-center pb-8">
                  <CardTitle className="text-white text-3xl mb-4">
                    {t.pricing.oneTime}
                  </CardTitle>
                  <div className="text-6xl font-bold text-purple-400 mb-2">$120</div>
                  <p className="text-gray-300">Tek seferlik ödeme</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  {t.pricing.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <Check className="h-5 w-5 text-green-400 flex-shrink-0" />
                      <span className="text-gray-300">{feature}</span>
                    </div>
                  ))}
                  <Button className="w-full mt-8 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-3">
                    <Download className="h-5 w-5 mr-2" />
                    Hemen Satın Al
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              whileHover={{ scale: 1.05 }}
            >
              <Card className="bg-white/5 border-white/10 backdrop-blur-sm h-full">
                <CardHeader className="text-center pb-8">
                  <CardTitle className="text-white text-3xl mb-4">
                    {t.pricing.monthly}
                  </CardTitle>
                  <div className="text-6xl font-bold text-blue-400 mb-2">$18</div>
                  <p className="text-gray-300">Aylık ödeme</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  {t.pricing.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <Check className="h-5 w-5 text-green-400 flex-shrink-0" />
                      <span className="text-gray-300">{feature}</span>
                    </div>
                  ))}
                  <Button variant="outline" className="w-full mt-8 border-blue-400 text-blue-300 hover:bg-blue-600/20 py-3">
                    Aylık Başla
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 bg-slate-900/50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
              {t.faq.title}
            </h2>
          </motion.div>

          <div className="max-w-3xl mx-auto space-y-6">
            {[
              { q: t.faq.q1, a: t.faq.a1 },
              { q: t.faq.q2, a: t.faq.a2 },
              { q: t.faq.q3, a: t.faq.a3 }
            ].map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-300">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">
                      {faq.q}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-300">
                      {faq.a}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-pink-600">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Yaratıcılığınızı Serbest Bırakın
            </h2>
            <p className="text-xl text-purple-100 mb-8 max-w-2xl mx-auto">
              Pixel Wizard AI ile sınırsız görsel üretiminin keyfini çıkarın. Hemen indirin ve farkı yaşayın!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-4 text-lg font-bold">
                <Download className="h-5 w-5 mr-2" />
                Ücretsiz Deneme - $120
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20 px-8 py-4 text-lg">
                Telegram Kanalımız
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Wand2 className="h-8 w-8 text-purple-400" />
              <span className="text-2xl font-bold text-white">Pixel Wizard AI</span>
            </div>
            
            <div className="flex items-center space-x-6">
              <a 
                href="https://t.me/pixel_wizard_ai" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-purple-400 hover:text-purple-300 transition-colors flex items-center space-x-2"
              >
                <MessageCircle className="h-5 w-5" />
                <span>{t.footer.telegram}</span>
              </a>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400">
              © 2024 Pixel Wizard AI. {t.footer.rights}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
